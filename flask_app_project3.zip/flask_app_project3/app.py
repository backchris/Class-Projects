import datetime
from turtle import title
from wsgiref.validate import validator
from flask import Flask, render_template, flash, url_for, redirect
# from datetime import datetime
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo 
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from os import path
from sqlalchemy.exc import SQLAlchemyError
#from app import db

# The following command imports a CLASS: SignUpForm from form.py file:
# from form import SignUpForm

app = Flask(__name__)
app.config['SECRET_KEY'] = "YOU-WILL-NEVER-KNOW"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)
#####
db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
#####
login_manager.init_app
######
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# with app.app_context():
#     db.create_all()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key = True)
    username = db.Column(db.String(15), nullable= False, unique=True)
    #, unique=True
    email = db.Column(db.String(50), nullable= False, unique=True)
    #, unique=True
    password_hash = db.Column(db.String(80), nullable= False)
    posts = db.relationship('Post', backref='author', lazy='dynamic')
    joined_date = db.Column(db.DateTime, default= datetime.datetime.utcnow)
    location = db.Column(db.String(50), nullable= False)
    bio= db.Column(db.String(500), nullable=True)



    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        print(self.password_hash)
        print(password)
        return check_password_hash(self.password_hash, password)

    def __repr__(self) -> str:
        return '<User {}>'.format(self.username)

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.String(150))
    timestamp = db.Column(db.DateTime, index=True, default=datetime.datetime.utcnow())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

    def __repr__(self) -> str:
        return '<Post {}>'.format(self.message)

class Group(db.Model):
    id= db.Column(db.Integer, primary_key=True)
    groupName= db.Column(db.String(150), unique=True)
    timestamp = db.Column(db.DateTime, index=True, default=datetime.datetime.utcnow())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

    def __repr__(self) -> str:
        return '<Group {}>'.format(self.groupName)

class SignUpForm(FlaskForm):
    username = StringField('Name', render_kw={'placeholder': 'Please input Name'}, validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('New Password', validators=[DataRequired(), EqualTo('confirm', message= 'Passwords must match')])
    confirm = PasswordField('Confirm Password')
    location= StringField('Location', render_kw={'placeholder': 'Please input city'}, validators= [DataRequired()])
    bio= StringField('Bio', render_kw={'placeholder': 'Optional Bio'})
    submit = SubmitField('Sign Up')
    
class LoginForm(FlaskForm):
    # username = StringField('Username', render_kw={'placeholder': 'Please input Name'}, validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('remember me')
    submit = SubmitField('Login')

class PostForm(FlaskForm):
    message = TextAreaField('Message', validators=[DataRequired()])
    submit = SubmitField('Post')

class GroupForm(FlaskForm):
    groupName= StringField('Group Name', validators=[DataRequired()])
    submit= SubmitField('Create Group')

@app.route("/")
def home():
    return render_template("first.html")
    #return "Hello"

@app.route("/first/")
def first():
    return "Hello"
    #return render_template("first.html")

@app.route("/list/")
def list():
    return render_template("list.html")

@app.route("/signup/", methods=['GET', 'POST'] )
def signup():
    form = SignUpForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(email=form.email.data).first()
        if existing_user is None:
            user = User(username=form.username.data, email=form.email.data, location= form.location.data, bio= form.bio.data)
            user.set_password(form.password.data)
            ####added try and exception statements
            try: 
                db.session.add(user)
                db.session.commit()
            except SQLAlchemyError as e:
                reason= str(e)
                return reason
            login_user(user)
            return '<h1>New User has been created!</h1>' 
        flash("A user already exists with that email address.")
        print("A user already exists with that email address.")
    return render_template("signup.html", title="Sign Up Page", form = form)

@app.route("/login/", methods=['GET', 'POST'] )
def login():
    form = LoginForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(email=form.email.data).first()
        
        if existing_user is None or not existing_user.check_password(form.password.data):
            flash("Invalid username or password!")
            print("Invalid username or password!")
            #return redirect(url_for('events'))
            return render_template("login.html", form=form)

        login_user(existing_user, remember=form.remember_me.data)
        #user = User(username=form.username.data, email=form.email.data)
        flash("Successful!")
        print("Successful!")
        ##### changed first to events page
        return redirect(url_for('user_home', username=current_user.username))

    flash("Failure")
    print("Failure")
    return render_template("login.html", title="Login Page", form = form)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route("/events/", methods=['GET', 'POST'] )
def events():
    return render_template("events.html")

@app.route("/user/")
@app.route("/user/<username>", methods=['GET', 'POST'] )
@login_required
def user_home(username):
    form = PostForm()
    if form.validate_on_submit():
        #message = form.message.data 
        #user = User.query.filter_by(username=username).first()
        print("my")
        #print(message)
        #print(user)
        # _or_404
        # user_id = user.id
        ####post= Post(message)
        post = Post(message=form.message.data, user_id= User.query.filter_by(username=username).first())
        print("nuts")
        print(post)

        db.session.add(post)
        db.session.commit()
        print("bust")
    #posts = Post.query.all()
    
    #return render_template("first.html")
    return render_template("user_home.html", form=form, username=username) #, posts=posts

@app.route("/user/")
@app.route("/user/<username>/profile", methods=['GET', 'POST'] )
@login_required
def profile(username):
    return render_template("profile.html", username=username)

@app.route("/user/")
@app.route("/user/<username>/groups", methods=['GET', 'POST'] )
@login_required
def groups(username):
    return render_template("groups.html", username=username)

@app.route("/user/")
@app.route("/user/<username>/createGroup", methods=['GET', 'POST'] )
@login_required
def createGroup(username):
    form = GroupForm()
    if form.validate_on_submit():
        existing_group = Group.query.filter_by(groupName=form.groupName.data).first()
        if existing_group is None:
            group= Group(groupName= form.groupName.data)
            try: 
                db.session.add(group)
                db.session.commit()
            except SQLAlchemyError as e:
                reason= str(e)
                return reason
            return '<h1>New Group has been created!</h1>' 
        print("Group already exists with that name")
    return render_template("createGroup.html", username=username, form= form)


if __name__ == "__main__":
    app.run(debug=True)